﻿namespace WebApplication1.Models
{
    public class EmpresaModel
    {
        public string NomeEmpresa { get; set; } = string.Empty;
        public string Endereco { get; set; } = string.Empty;
        public string RegimeFiscal { get; set; } = string.Empty;
        public int CNPJ { get; set; }
        public int MargemDesconto { get; set; }

 

    }
}
