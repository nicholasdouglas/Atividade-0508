﻿namespace WebApplication1.Models
{
    public class PedidoModel
    {
        public string NomeProduto { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
        public DateTime DataEntrada { get; set; }
        public string Responsavel { get; set; } = string.Empty;
        



    }
}
