using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Views.Amogus.Empresa
{
    public class EmpresaModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
