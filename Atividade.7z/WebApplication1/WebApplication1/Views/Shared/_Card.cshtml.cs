using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication1.Views.Shared
{
    public class _CardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
