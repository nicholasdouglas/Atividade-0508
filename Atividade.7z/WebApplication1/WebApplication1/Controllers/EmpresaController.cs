﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;


namespace WebApplication1.Controllers
{
    public class EmpresaController : Controller
    {
        public IActionResult Index()
        {
            var empresa = new List<EmpresaModel>
            {
                new EmpresaModel
                {
                    NomeEmpresa = "Amasus S.A",
                    Endereco = "Rua Alberto Santos de Albuquerque, 3",
                    RegimeFiscal = "Sim",
                    CNPJ = 254546,
                    MargemDesconto = 10
                }
                
            };

            return View(empresa);
        }

    }
}
