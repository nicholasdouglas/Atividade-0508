﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class AmogusController : Controller
    {
        public IActionResult Index()
        {
            var amogus = new List<AmogusModel>
            {
                new AmogusModel
                {
                    Id = 1,
                    Nome = "Cigarro Malboro",
                    Valor = 5.79m,
                    Descr = "Você vai ficar broxa hein kkkkkkkk",
                    DataFabric = new DateTime (2024, 07, 31, 09, 42, 04)

                },
                new AmogusModel
                {
                    Id = 2,
                    Nome = "Trident X",
                    Valor = 4m,
                    Descr = "Chiclete de menta",
                    DataFabric = new DateTime(2024, 07, 31, 09, 42, 04)
                }
            };

            return View(amogus);
        }
    }
}

