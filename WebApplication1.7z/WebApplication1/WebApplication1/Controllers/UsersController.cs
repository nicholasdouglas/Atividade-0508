﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class UsersController : Controller
    {
        public IActionResult Index()
        {
            var user = new List<UsersModel>
            {
                new UsersModel
                {
                    IdUser = 1,
                    NomeUser = "Walter",
                    Email = "bluemethguy@yahoo.com.br.org.pr.sesi",
                    CPF = 14,
                    Endereco = "Rua Cristal Azul, 5, Novo México",
                    Telefone = 344546

                },
            };

            return View(user);
        }
    }
}

