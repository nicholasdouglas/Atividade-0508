﻿namespace WebApplication1.Models
{
    public class UsersModel
    {   
        public int IdUser { get; set; }
        public string NomeUser { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public int CPF { get; set; }
        public string Endereco { get; set; } = string.Empty;
        public int Telefone { get; set; }



    }
}
